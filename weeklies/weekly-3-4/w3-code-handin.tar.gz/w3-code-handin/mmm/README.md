# Matrix-Matrix Multiplication (MMM): Cuda Exercise 3

See section "L1$ and Register: Matrix-Matrix Multiplication" in companion lecture slides.

The programming task refers to implementing some of the code of Cuda kernel `mmmSymBlkRegInnSeqKer` in file `kernels.cu.h`. Please search for keyword "Exercise" in file `kernels.cu.h` to find the implementation place, and follow the instructions there. 
